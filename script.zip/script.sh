#!/bin/sh
trap "killall TMiner" EXIT
while :
 do
if pgrep TMiner; then
 killall TMiner 
fi
./TMiner &
sleep 90m
done
